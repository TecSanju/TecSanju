# openinAPP
Create UI components from the response you shall be getting from the given api url and populate the data mentioned below accordingly from the given UI template 1) Display greeting from the local time 2) Create a chart from the given api response 3) Add a Tab [Top links &amp; Recent links] and create a list view to display the data .
