<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

$select_likes = $conn->prepare("SELECT * FROM `likes` WHERE user_id = ?");
$select_likes->execute([$user_id]);
$total_likes = $select_likes->rowCount();

$select_comments = $conn->prepare("SELECT * FROM `comments` WHERE user_id = ?");
$select_comments->execute([$user_id]);
$total_comments = $select_comments->rowCount();

$select_bookmark = $conn->prepare("SELECT * FROM `bookmark` WHERE user_id = ?");
$select_bookmark->execute([$user_id]);
$total_bookmarked = $select_bookmark->rowCount();

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>home</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php include 'components/user_header.php'; ?>


<!-- quick select section starts  -->

<section class="quick-select">

   <h1 class="heading">quick options</h1>

   <div class="box-container">

      

      <div class="box">
         <h3 class="title">Internships Slots Available:</h3>
         <div class="flex">
         <a href="webdev.php"><i class="fas fa-vial"></i><span>Computer Science Engineering </span></a>
            <a href="webdev.php?"><i class="fas fa-code"></i><span>Website Development</span></a>
            <a href="applicationdev.php"><i class="fab fa-android"></i><span>Application Development</span></a>
            <a href="mecheng.php"><i class="fas fa-vial"></i><span>Mechanical Engineering</span></a>
            <a href="3dprinting.php"><i class="fas fa-vial"></i><span>3D Printing</span></a>
            <a href="ec.php"><i class="fas fa-vial"></i><span>Electronics & Communication Engineering</span></a>
            <a href="civileng.php"><i class="fas fa-vial"></i><span>Civil Engineering</span></a>
            <a href="hrintern.php"><i class="fab fa-creative-commons-nc"></i><span>Human Resources</span></a>
            <a href="finance.php"><i class="fas fa-vial"></i><span>Finacial modeling & Investment banking</span></a>
            <a href="digitalmarketing.php"><i class="fas fa-vial"></i><span>Digital Marketing & SEO</span></a>
            <a href="finance.php"><i class="fas fa-vial"></i><span>Stock Market</span></a>
            <a href="contentwriting.php"><i class="fas fa-vial"></i><span>Content Writing</span></a>
            <a href="microandmacro.php"><i class="fas fa-vial"></i><span>Micro & Macro-Economics</span></a>
            <a href="advandpr.php"><i class="fas fa-chart-line"></i><span>Advertising & PR</span></a>
            <a href="businessstudiesandecommerce.php"><i class="fas fa-music"></i><span>Business Studies & Commerce</span></a>
            <a href="factchecing"><i class="fas fa-camera"></i><span>Fact Checking / Proof Reading</span></a>
            <a href="https://docs.google.com/forms/d/e/1FAIpQLSc9LjO3IKVadJltw7BWLY0RUoDB7xN9qJ955uyMdMse3CFU5w/viewform"><i class="fas fa-cog"></i><span>Other..</span></a>
            
         </div>
      </div>

      <div class="box">
         <h3 class="title">Popular Project:</h3>
         <div class="flex">
            <a href="#"><i class="fab fa-html5"></i><span>IOT Projects</span></a>
            <a href="#"><i class="fab fa-css3"></i><span>Mechanical Projects</span></a>
            <a href="#"><i class="fab fa-js"></i><span>3D Printing Projects</span></a>
            <a href="#"><i class="fab fa-react"></i><span>Website and Application Development</span></a>
            <a href="#"><i class="fab fa-php"></i><span>PHP</span></a>
            <a href="#"><i class="fab fa-bootstrap"></i><span>Software Development Projects</span></a>
            <a href="#"><i class="fab fa-php"></i><span>VLSI Project</span></a>
            <a href="#"><i class="fab fa-php"></i><span>Embaded System Projects</span></a>

         </div>
      </div>

      <div class="box tutor">
         <h3 class="title">Courses</h3>
         <p>Coming Soon!!...</p>
         <a href="admin/register.php" class="inline-btn">get started</a>
      </div>

   </div>

</section>

<!-- quick select section ends -->


<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<!-- about section starts  -->

<section class="about">

   <div class="row">

      <div class="image">
         <img src="images/about-img.svg" alt="">
      </div>

      <div class="content">
         <h3>Why Choose us?</h3>
         <p>
         EDUPHOENIX SOLUTIONS has its origins dating back to 2019 in Bangalore. Since its authorization for training cum internship services in 2021, the company has continuously progressed. With a remarkable track record of successful projects, we take immense pride in being one of the most trusted Engineering, Internships & Training Services in Bangalore. Moreover, our reputation has expanded across India, with services offered in various states such as Delhi, Aurangabad (M.H), and more.

In response to the demand for skill development and training programs, we diversified our services in 2021 to cater to both Engineering and non-engineering students in different domains. This step was taken to address the issue of unemployment among the vast number of Engineering graduates that India produces annually. While the country generates 1.5 million Engineering graduates each year, it is a widely acknowledged fact that a significant portion, around 75%, remain unemployed. Hence, there arises a crucial need to provide skill training and bridge the gap between theoretical knowledge and industry requirements.

In 2018, AICTE made internships mandatory for Engineering students, and BCU followed suit for non-engineering students. These initiatives aimed to expose students to the industrial environment, current technologies relevant to their subjects, and opportunities to develop real-time technical and managerial skills. In response to requests from colleges seeking quality internships, we started providing expert-led internship programs to students.
        </p> <a href="Internship.php" class="inline-btn">Our Internships</a>
      </div>

   </div>

   <div class="box-container">

      <div class="box">
         <i class="fas fa-graduation-cap"></i>
         <div>
            <h3>Virtual Interships:</h3>
            <span>Online Meetings.</span>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-user-graduate"></i>
         <div>
            <h3>2500+</h3>
            <span>Brilliant Students.</span>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-chalkboard-user"></i>
         <div>
            <h3>30+</h3>
            <span>Internship Batches.</span>
         </div>
      </div>

      <div class="box">
         <i class="fas fa-briefcase"></i>
         <div>
            <h3>AICTE</h3>
            <span>Approved Certificates.</span>
         </div>
      </div>

   </div>

</section>

<!-- about section ends -->
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>

<!-- 
<section class="reviews">

   <h1 class="heading">student's reviews</h1>

   <div class="box-container">

      <div class="box">
         <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo fugiat, quaerat voluptate odio consectetur assumenda fugit maxime unde at ex?</p>
         <div class="user">
            <img src="images/pic-2.jpg" alt="">
            <div>
               <h3>john deo</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo fugiat, quaerat voluptate odio consectetur assumenda fugit maxime unde at ex?</p>
         <div class="user">
            <img src="images/pic-3.jpg" alt="">
            <div>
               <h3>john deo</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo fugiat, quaerat voluptate odio consectetur assumenda fugit maxime unde at ex?</p>
         <div class="user">
            <img src="images/pic-4.jpg" alt="">
            <div>
               <h3>john deo</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo fugiat, quaerat voluptate odio consectetur assumenda fugit maxime unde at ex?</p>
         <div class="user">
            <img src="images/pic-5.jpg" alt="">
            <div>
               <h3>john deo</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo fugiat, quaerat voluptate odio consectetur assumenda fugit maxime unde at ex?</p>
         <div class="user">
            <img src="images/pic-6.jpg" alt="">
            <div>
               <h3>john deo</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
      </div>

      <div class="box">
         <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Illo fugiat, quaerat voluptate odio consectetur assumenda fugit maxime unde at ex?</p>
         <div class="user">
            <img src="images/pic-7.jpg" alt="">
            <div>
               <h3>john deo</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
               </div>
         </div>
      </div>

   </div>

</section>  -->


<!-- reviews section ends -->


   

   </div>

</section>

<!-- quick select section ends -->
<br><br><br><br><br><br><br><br><br><br><br><br>
<!-- courses section starts  -->
<!-- courses section ends -->



<br><br><br><br><br><br><br><br><br><br><br><br>
<!-- contact section starts  -->

<section class="contact">

<div class="row">

<div class="image">
   <img src="images/contact-img.svg" alt="">
</div>

<form action="" method="post">
   <h3>Get In Touch</h3>
   <input type="text" placeholder="enter your name" required maxlength="100" name="name" class="box">
   <input type="email" placeholder="enter your email" required maxlength="100" name="email" class="box">
   <input type="number" min="0" max="9999999999" placeholder="enter your number" required maxlength="10" name="number" class="box">
   <textarea name="msg" class="box" placeholder="enter your message" required cols="30" rows="10" maxlength="1000"></textarea>
   <input type="submit" value="send message" class="inline-btn" name="submit">
</form>

</div>
<br><br><br><br><br><br><br><br>
<div class="box-container">

<div class="box">
   <i class="fas fa-phone"></i>
   <h3>Phone Number:</h3>
   <a href="tel:9886473833">988-647-3833</a>
</div>

<div class="box">
   <i class="fas fa-envelope"></i>
   <h3>E-mail Address:</h3>
   <a href="mailto:eduphoenixsolutions@gmail.com">eduphoenixsolutions@gmail.com</a>
</div>

<div class="box">
   <i class="fas fa-map-marker-alt"></i>
   <h3>Office Address:</h3>
   <a href="https://www.google.com/search?rlz=1C1ONGR_enIN1064IN1064&tbs=lf:1,lf_ui:2&tbm=lcl&sxsrf=AB5stBhaWO07IlplgslF3clR8uzOIDoQzg:1690037026806&q=eduphoenix+private+limited&rflfq=1&num=10&rldimm=14364114589543371293&ved=2ahUKEwjz9o7FxqKAAxUCSWwGHT7yD2kQu9QIegQIGRAL#rlfi=hd:;si:14364114589543371293,l,ChplZHVwaG9lbml4IHByaXZhdGUgbGltaXRlZEil54DUsrmAgAhaKBAAEAEQAhgAGAEYAiIaZWR1cGhvZW5peCBwcml2YXRlIGxpbWl0ZWSSARZlZHVjYXRpb25hbF9jb25zdWx0YW50qgFCEAEyHhABIhraSeP2IfAZYx9k4zEy_tdnKxIMosqzVhSOUTIeEAIiGmVkdXBob2VuaXggcHJpdmF0ZSBsaW1pdGVk;mv:[[13.034421681990406,77.5988565968811],[13.017697269398369,77.58572450154419]]">No 18/3, Second Floor, First Main Road, Opp:108 'B' Bus Terminus, Ganganagar, Bengaluru, Karnataka 560032</a>
</div>


</div>

</section>

<!-- contact section ends -->



<!-- footer section starts  -->
<?php include 'components/footer.php'; ?>
<!-- footer section ends -->

<!-- custom js file link  -->
<script src="js/script.js"></script>
   
</body>
</html>