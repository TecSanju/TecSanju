<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>courses</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php include 'components/user_header.php'; ?>

<!-- courses section starts  -->

<section class="courses">

   <pre class="heading"><b>MICRO AND MACRO-ECONOMICS</b>                                                                                                                          
      <a href="https://docs.google.com/forms/d/e/1FAIpQLSc9LjO3IKVadJltw7BWLY0RUoDB7xN9qJ955uyMdMse3CFU5w/viewform" class="inline-btn">Apply Now</a></pre>

<section class="about">
<div class="box">
   <div class="row">
   <div class="box">
      <div class="image">
         <img src="images/about-img.svg" alt="">
      </div>

      <div class="content">
         <h3>Things to expect from this Intership:</h3>
         <p>
         3D printing, also known as additive manufacturing, is an innovative manufacturing process that transforms digital designs created through computer-aided design software (CAD) into tangible three-dimensional objects. This cutting-edge technology involves adding material layer by layer, utilizing various methods such as melting or softening the material to achieve the desired shape and structure. For professionals in the technical sector, a comprehensive training program will be provided, encompassing essential topics like CATIA software operation, hands-on experience with 3D printing machines, working with CREALITY software, mastering PLA printing techniques, and dedicating 10 hours of practice to reinforce the learning. <br><br>
            <h3>Training would include:</h3>
           <p>
           1.CATIA.
            <br>2. Hands on Machine.
            <br>3. CSS.
            <br>4. CREALITY SOFTWARE.
            <br>5. PLA Printing.
            <br><br>
            </p>
            <h3> Perks: </h3>
            <p>
           1. INTERNSHIP CERTIFICATE
            <br>2. INTERNSHIP REPORT
            <br>3. LETTER OF RECCOMENDATION
            </p>  <br><br>  
            <h3> Terms and Conditions: </h3>
            <p>
            Student or Candidate Must Pay ₹ 1100/- for Internship and Training Program which is AICTE approved.
            </p>     <br><br>              
            <h3> Number Of Openings:</h3>
            <p>
            35. </p> <br><br>
         <a href="https://docs.google.com/forms/d/e/1FAIpQLSc9LjO3IKVadJltw7BWLY0RUoDB7xN9qJ955uyMdMse3CFU5w/viewform" class="inline-btn">Apply Now</a>
      </div>
</div>

   </div>
</div>



</section>

<!-- courses section ends -->










<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>
   
</body>
</html>