<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>courses</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php include 'components/user_header.php'; ?>

<!-- courses section starts  -->

<section class="courses">

   <pre class="heading"> <b>ADVERTISING AND PR</b>
        <a href="https://docs.google.com/forms/d/e/1FAIpQLSc9LjO3IKVadJltw7BWLY0RUoDB7xN9qJ955uyMdMse3CFU5w/viewform" class="inline-btn">Apply Now</a></pre>
<section class="about">
<div class="box">
   <div class="row">
   <div class="box">
      <div class="image">
         <img src="images/about-img.svg" alt="">
      </div>

      <div class="content">
         <h3><b>Tings to know in training :</b></h3>
         <p> Discover the art of effectively communicating with clients,understanding their needs, providing top-notch services to exceed their expectations. Explore the creation of well-crafted media plans that align with clients' goals and objectives, ensuring maximum reach and exposure for their brands. Gain insights into the importance of generating insightful reports and conducting reviews to measure the success of PR campaigns and make data-driven improvements
</p>
 <br><br>
            <h3>Training would include:</h3>
            <p align=” justify”>1.Internship and Training Program Approved by AICTE.
            <br>2.Real-world Experience
            <br>3.Industry Insights
            <br>4.Creative Environment
            <br>5.Networking Opportunities
            <br>6.Free Projects and Much More....
            <br><br>
            </p>
            <h3> Perks: </h3>
            <p>1. INTERNSHIP CERTIFICATE
            <br>2. INTERNSHIP REPORT
            <br>3. LETTER OF RECCOMENDATION
            </p>  <br><br>  
            <h3> Who Can Apply: </h3>
            <p>
            Students pursuing degrees in Advertising, Public Relations, Marketing, Communications, or related fields</br>Individuals with a flair for creativity, excellent communication skills, and a passion for building brands</p>     <br><br>              
            
            <h3> Terms and Conditions: </h3>
            <p>
            Student or Candidate Must Pay ₹ 1100/- for Internship and Training Program which is AICTE approved.
            </p>     <br><br>              
            <h3> Number Of Openings:</h3>
            <p>
            35 </p> <br><br>
         <a href="https://docs.google.com/forms/d/e/1FAIpQLSc9LjO3IKVadJltw7BWLY0RUoDB7xN9qJ955uyMdMse3CFU5w/viewform" class="inline-btn">Apply Now</a>
      </div>
</div>

   </div>
</div>



</section>

<!-- courses section ends -->










<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>
   
</body>
</html>