<?php

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>courses</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>

<?php include 'components/user_header.php'; ?>

<!-- courses section starts  -->

<section class="courses">

   <pre class="heading"> <b>MECHANICAL ENGINEERING</b> <a href="https://docs.google.com/forms/d/e/1FAIpQLSc9LjO3IKVadJltw7BWLY0RUoDB7xN9qJ955uyMdMse3CFU5w/viewform" class="inline-btn">Apply Now</a></pre>
<section class="about">
<div class="box">
   <div class="row">
   <div class="box">
      <div class="image">
         <img src="images/about-img.svg" alt="">
      </div>

      <div class="content">
         <h3><b>Tings to know in training :</b></h3>
         <p>Delve into the heart of mechanical systems and learn about Power Train, the core component that drives various machines and vehicles,Delve into the heart of mechanical systems and learn about Power Train, the core component that drives various machines and vehicles,Explore the process of retrofitting traditional mechanical systems with modern and more efficient components, adapting them to contemporary demands,Gain experience in measuring and analyzing specimens, conducting research, and applying data to real-world applications</p>
 <br><br>
            <h3>Training would include:</h3>
           <p>
           1.Internship and Training Program Approved by AICTE.
            <br>2.Practical Training
            <br>3.Expert Mentors
            <br>4.Cutting-edge Facilities
            <br>5.Networking Opportunities
            <br>6. Free Projects and Much More....
            <br><br>
            </p>
            <h3> Perks: </h3>
            <p>
           1. INTERNSHIP CERTIFICATE
            <br>2. INTERNSHIP REPORT
            <br>3. LETTER OF RECCOMENDATION
            </p>  <br><br>  
            <h3> Who Can Apply: </h3>
            <p>
            Students pursuing Electronics and Communication Engineering or related disciplines</br>Enthusiastic individuals eager to expand their knowledge and skills in electronics technology </p>     <br><br>              
            
            <h3> Terms and Conditions: </h3>
            <p>
            Student or Candidate Must Pay ₹ 1100/- for Internship and Training Program which is AICTE approved.
            </p>     <br><br>              
            <h3> Number Of Openings:</h3>
            <p>
            35 </p> <br><br>
         <a href="https://docs.google.com/forms/d/e/1FAIpQLSc9LjO3IKVadJltw7BWLY0RUoDB7xN9qJ955uyMdMse3CFU5w/viewform" class="inline-btn">Apply Now</a>
      </div>
</div>

   </div>
</div>



</section>

<!-- courses section ends -->










<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>
   
</body>
</html>