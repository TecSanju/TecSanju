<footer class="footer">

   &copy; Copyright @ <?= date('Y'); ?> by <a href="https://www.google.com/search?q=eduphoenix+private+limited&rlz=1C1ONGR_enIN1064IN1064&oq=edu&gs_lcrp=EgZjaHJvbWUqBggCEEUYOzIGCAAQRRg8MgYIARBFGDkyBggCEEUYOzIGCAMQRRg7MgYIBBBFGDsyBggFEEUYPDIGCAYQRRg8MgYIBxBFGDzSAQgzNTEzajBqN6gCALACAA&sourceid=chrome&ie=UTF-8"></i><span>Eduphoenix Private Limited</span></a> | All Rights Reserved!
    <div class="box">
         <a href="https://www.instagram.com/eduphoenix_solutions/"><i class="fab fa-instagram"></i><span>Instagram</span></a>
         <a href="https://www.linkedin.com/company/eduphoenix-private-limited/?originalSubdomain=in"><i class="fab fa-linkedin"></i><span>Linkedin</span></a>
         <a href="terms&conditions.php"><i class="fab fa-facebook"></i><span>Facebook</span></a>
         <a href="https://www.youtube.com/channel/UCWoIW9jfghAJ75uVMmxkRBg"><i class="fab fa-youtube"></i><span>Youtube</span></a>
         <a href="T&C.pdf"><i class="fab fa-readme"></i><span>Terms & Conditions</span></a>
      </div>

</footer>