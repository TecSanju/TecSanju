<footer class="footer">

   &copy; copyright @ <?= date('Y'); ?> by <span>Eduphoenix Private Limited</span> | All Rights Reserved!

</footer>